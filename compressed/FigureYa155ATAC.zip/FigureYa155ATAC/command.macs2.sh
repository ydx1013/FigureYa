macs2 callpeak --nomodel -t *.bam -q 0.01 -f BAM -g mm --keep-dup all --llocal 10000 -n * 2> *.macs2.log
